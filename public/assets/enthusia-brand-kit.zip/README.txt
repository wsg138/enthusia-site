Enthusia creator assets

Includes the logo and spawn screenshot already used on the Enthusia website.
Use these assets when making content about Enthusia.
Find additional screenshots in the website Gallery.
